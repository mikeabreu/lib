package main;

public class App {

	public static void main(String[] args) {

		Phonebook pb1 = new Phonebook();
		pb1.run();
	}

}
