
public class LLNode 
// Author: Michael Abreu
{
	
	// Instance variables
	// link holds the memory address pointer to the next node.
	// info holds the data.
	private LLNode link;
	private String firstName, lastName;
	
	
	public LLNode (String firstName, String lastName)
	// Preconditions: requires you to pass a data of type String
	//
	// Creates a Link List holding data of type String
	{
		this.firstName = firstName;
		this.lastName = lastName;
		link = null;
	}

	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getName() 
	// Returns the String inside the node.
	{
		return firstName + " " + lastName;
	}

	public void setName(String firstName, String lastName) 
	// Preconditions: requires a String to be passed in.
	//
	// Change the data inside the node.
	{
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public LLNode getLink() 
	// Returns the memory address the node is pointing at.
	{
		return link;
	}

	public void setLink(LLNode link) 
	// Preconditions: Must be of type LLNode
	//
	// Sets the memory address the node will point to.
	{
		this.link = link;
	}
}
